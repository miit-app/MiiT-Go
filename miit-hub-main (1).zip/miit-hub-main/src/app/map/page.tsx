import { notFound } from 'next/navigation';

export default function MapPage() {
  notFound();
  return null;
}
